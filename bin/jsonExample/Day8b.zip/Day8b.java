package jsonExample;

import java.io.FileInputStream;
import java.io.InputStream;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;




public class Day8b {
	

	    public static void main(String[] args) throws Exception {
	    	try {
	    	InputStream in=new FileInputStream("D:\\prac\\InputJson (2).json");
			int i=0;
			String s="";
			while ((i=in.read())!=-1) {
				System.out.print((char)i);
				s+=(char)i;
				
			}

			JSONObject obj=(JSONObject)JSONValue.parse(s);
			System.out.println(obj.get("data"));
		
	    	
	    	
	    	in.close();
	    }catch (Exception e) {
			e.printStackTrace();
		}

	}
}

